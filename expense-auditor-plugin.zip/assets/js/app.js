/*
  Expense Auditor - client-side rule-based analysis
  - Parses CSV (simple parser)
  - Detects duplicates, unusual amounts (z-score), spikes per month, suspicious vendors
  - Allows CSV export and PDF export (jsPDF)
*/

(function(){
  const $ = id => document.getElementById(id);
  const fileInput = $('ea-file');
  const parseBtn = $('ea-parse');
  const exportCsvBtn = $('ea-export-csv');
  const exportPdfBtn = $('ea-export-pdf');
  const resultsDiv = $('ea-results');
  const hasHeader = $('ea-has-header');
  const parseLocale = $('ea-parse-locale');

  let lastAnalysis = null;

  function parseCSV(text){
    // Very basic CSV parser (handles quoted fields)
    const rows = [];
    let cur = '';
    let row = [];
    let inQuotes = false;
    for (let i=0;i<text.length;i++){
      const ch = text[i];
      const next = text[i+1] || '';
      if (ch === '"'){
        if (inQuotes && next === '"'){ cur += '"'; i++; continue; }
        inQuotes = !inQuotes;
        continue;
      }
      if (!inQuotes && (ch === '\n' || ch === '\r')){
        if (ch === '\r' && next === '\n'){ i++; } // skip windows newline
        row.push(cur); cur = '';
        rows.push(row); row = [];
        continue;
      }
      if (!inQuotes && ch === ','){ row.push(cur); cur = ''; continue; }
      cur += ch;
    }
    // last field
    if (cur !== '' || row.length){
      row.push(cur);
      rows.push(row);
    }
    return rows;
  }

  function toNumber(s){
    if (s === null || s === undefined) return NaN;
    s = String(s).trim();
    if (!s.length) return NaN;
    // handle locale option: if parseLocale checked, treat comma as decimal separator
    if (parseLocale.checked){
      s = s.replace(/\./g,'').replace(/,/g,'.');
    } else {
      s = s.replace(/,/g,'');
    }
    // remove currency symbols
    s = s.replace(/[^0-9.\-]/g,'');
    return parseFloat(s);
  }

  function detectColumns(headerRow){
    // find likely columns: date, vendor, amount, category
    const map = {};
    headerRow.forEach((h, idx) => {
      const key = String(h || '').toLowerCase();
      if (key.match(/date/)) map.date = idx;
      else if (key.match(/vendor|payee|merchant/)) map.vendor = idx;
      else if (key.match(/amount|amt|value|debit|credit/)) map.amount = idx;
      else if (key.match(/category|cat/)) map.category = idx;
    });
    return map;
  }

  function parseRows(rows){
    let start = 0;
    let columns = {};
    if (hasHeader.checked){
      columns = detectColumns(rows[0] || []);
      start = 1;
    } else {
      // default positions
      columns = { date:0, vendor:1, amount:2, category:3 };
    }
    const tx = [];
    for (let i=start;i<rows.length;i++){
      const r = rows[i];
      if (!r || r.length === 0) continue;
      const date = r[columns.date] || r[0] || '';
      const vendor = (r[columns.vendor] || r[1] || '').trim();
      const amountRaw = r[columns.amount] || r[2] || '';
      const category = r[columns.category] || r[3] || '';
      const amount = toNumber(amountRaw);
      if (isNaN(amount)) continue;
      tx.push({date: date.trim(), vendor: vendor || 'Unknown', amount: amount, category: category.trim(), raw: r});
    }
    return tx;
  }

  function groupBy(arr, keyFn){
    const map = new Map();
    arr.forEach(item => {
      const key = keyFn(item);
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(item);
    });
    return map;
  }

  function monthKey(dateStr){
    // try to parse YYYY-MM-DD or DD/MM/YYYY etc.; fallback to first 7 chars
    const d = new Date(dateStr);
    if (!isNaN(d)) return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0');
    // fallback parse like DD/MM/YYYY or MM/DD/YYYY
    const parts = dateStr.split(/[\/\-]/).map(p=>p.trim());
    if (parts.length >=3){
      const year = parts[2].length === 4 ? parts[2] : parts[0];
      const month = parts[1] || '01';
      return year + '-' + String(month).padStart(2,'0');
    }
    return dateStr.slice(0,7);
  }

  function zScores(values){
    const n = values.length;
    if (n === 0) return [];
    const mean = values.reduce((a,b)=>a+b,0)/n;
    const variance = values.reduce((a,b)=>a + Math.pow(b-mean,2),0)/n;
    const sd = Math.sqrt(variance) || 0.00001;
    return values.map(v => (v-mean)/sd);
  }

  function analyze(transactions){
    const issues = [];
    const seen = new Map();
    transactions.forEach((t, idx) => {
      const key = (t.date||'') + '||' + (t.vendor||'') + '||' + String(t.amount);
      if (seen.has(key)) {
        issues.push({type:'duplicate', message:'Duplicate transaction', tx: t, other: seen.get(key)});
      } else seen.set(key, t);
    });

    const byVendor = groupBy(transactions, t => t.vendor.toLowerCase());
    const amounts = transactions.map(t=>t.amount);
    const overallZ = zScores(amounts);
    transactions.forEach((t, idx) => { t.overallZ = overallZ[idx]; });

    byVendor.forEach((list, vendor) => {
      const vals = list.map(x=>x.amount);
      const zs = zScores(vals);
      list.forEach((item, i) => { item.vendorZ = zs[i]; });
    });

    transactions.forEach(t => {
      if (Math.abs(t.overallZ) >= 2) issues.push({type:'unusual_amount', message:'Unusual amount compared to all transactions', tx: t, score: t.overallZ});
      if (t.vendorZ !== undefined && Math.abs(t.vendorZ) >= 2) issues.push({type:'vendor_outlier', message:'Unusual amount for this vendor', tx: t, score: t.vendorZ});
    });

    const byMonth = groupBy(transactions, t => monthKey(t.date));
    const months = Array.from(byMonth.keys()).sort();
    const monthTotals = months.map(m => byMonth.get(m).reduce((a,b)=>a+b.amount,0));
    for (let i=1;i<months.length;i++){
      const prev = monthTotals[i-1] || 0;
      const cur = monthTotals[i] || 0;
      if (prev > 0 && (cur - prev)/prev > 0.5){
        issues.push({type:'spike', message:'Month-over-month spike detected', month: months[i], previous: prev, current: cur});
      }
    }

    const total = amounts.reduce((a,b)=>a+b,0) || 1;
    byVendor.forEach((list, vendor) => {
      const sum = list.reduce((a,b)=>a+b.amount,0);
      if (list.length === 1 && sum / total > 0.1) {
        issues.push({type:'suspicious_vendor', message:'One-off large payment to vendor', vendor: vendor, amount: sum});
      }
      if (sum / total > 0.2){
        issues.push({type:'heavy_vendor', message:'Vendor represents large share of spend', vendor: vendor, amount: sum});
      }
    });

    return { transactions, issues, summary: { total: total, count: transactions.length } };
  }

  function renderAnalysis(res){
    if (!res) { resultsDiv.innerHTML = '<p>No data</p>'; return; }
    const tx = res.transactions;
    const issues = res.issues;
    let html = '<div class="ea-meta"><strong>Transactions:</strong> ' + res.summary.count + ' &nbsp; <strong>Total:</strong> ' + res.summary.total.toFixed(2) + '</div>';
    if (issues.length === 0) html += '<p>No issues detected.</p>';
    else {
      html += '<h3>Flags (' + issues.length + ')</h3><ul>';
      issues.forEach((it, idx) => {
        if (it.type === 'duplicate'){
          html += '<li class="ea-flag">[Duplicate] ' + escapeHtml(it.tx.vendor) + ' | ' + it.tx.amount.toFixed(2) + ' | ' + escapeHtml(it.tx.date) + '</li>';
        } else if (it.type === 'unusual_amount'){
          html += '<li class="ea-flag">[Unusual Amount] ' + escapeHtml(it.tx.vendor) + ' | ' + it.tx.amount.toFixed(2) + ' | z=' + it.score.toFixed(2) + '</li>';
        } else if (it.type === 'vendor_outlier'){
          html += '<li class="ea-flag">[Vendor Outlier] ' + escapeHtml(it.tx.vendor) + ' | ' + it.tx.amount.toFixed(2) + ' | vendor z=' + it.score.toFixed(2) + '</li>';
        } else if (it.type === 'spike'){
          html += '<li class="ea-flag">[Spike] ' + escapeHtml(it.month) + ' increased from ' + it.previous.toFixed(2) + ' to ' + it.current.toFixed(2) + '</li>';
        } else if (it.type === 'suspicious_vendor'){
          html += '<li class="ea-flag">[Suspicious Vendor] ' + escapeHtml(it.vendor) + ' single payment ' + it.amount.toFixed(2) + '</li>';
        } else if (it.type === 'heavy_vendor'){
          html += '<li class="ea-flag">[Heavy Spend] ' + escapeHtml(it.vendor) + ' total ' + it.amount.toFixed(2) + '</li>';
        } else {
          html += '<li>' + escapeHtml(String(it.message || JSON.stringify(it))) + '</li>';
        }
      });
      html += '</ul>';
    }

    html += '<h3>Transactions</h3><table class="ea-table"><thead><tr><th>#</th><th>Date</th><th>Vendor</th><th>Amount</th><th>Category</th></tr></thead><tbody>';
    tx.forEach((t, i) => {
      html += '<tr><td>' + (i+1) + '</td><td>' + escapeHtml(t.date) + '</td><td>' + escapeHtml(t.vendor) + '</td><td>' + t.amount.toFixed(2) + '</td><td>' + escapeHtml(t.category || '') + '</td></tr>';
    });
    html += '</tbody></table>';
    resultsDiv.innerHTML = html;
  }

  function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  function enableExports(data){
    if (!data) { exportCsvBtn.disabled = true; exportPdfBtn.disabled = true; return; }
    exportCsvBtn.disabled = false; exportPdfBtn.disabled = false;
    exportCsvBtn.onclick = ()=> downloadCSV(data);
    exportPdfBtn.onclick = ()=> downloadPDF(data);
  }

  function downloadCSV(analysis){
    const header = ['Date','Vendor','Amount','Category','Flags'];
    const rows = analysis.transactions.map(t => {
      const flags = [];
      if (Math.abs(t.overallZ || 0) >= 2) flags.push('unusual');
      if (Math.abs(t.vendorZ || 0) >= 2) flags.push('vendor_outlier');
      return [t.date, t.vendor, t.amount.toFixed(2), t.category || '', flags.join(';')];
    });
    let csv = header.join(',') + '\n' + rows.map(r => r.map(cell => '"' + String(cell).replace(/"/g,'""') + '"').join(',')).join('\n');
    const blob = new Blob([csv], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'expense-audit.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  async function downloadPDF(analysis){
    const jsPDFCtor = (window.jspdf && window.jspdf.jsPDF) ? window.jspdf.jsPDF : (window.jsPDF || null);
    if (!jsPDFCtor){
      alert('PDF library not found. Ensure jsPDF is loaded.');
      return;
    }
    const doc = new jsPDFCtor();
    doc.setFontSize(16);
    doc.text('Expense Audit Report', 14, 20);
    doc.setFontSize(10);
    let y = 30;
    doc.text('Summary: Transactions: ' + analysis.summary.count + ' Total: ' + analysis.summary.total.toFixed(2), 14, y);
    y += 8;
    if (analysis.issues && analysis.issues.length){
      doc.text('Flags (' + analysis.issues.length + '):', 14, y); y += 6;
      analysis.issues.slice(0,20).forEach((it, idx) => {
        const line = (it.type || '') + ' - ' + (it.message || '') + (it.vendor ? (' ' + it.vendor) : '') + (it.tx ? (' ' + (it.tx.vendor || '') + ' ' + (it.tx.amount || '')) : '');
        doc.text((idx+1) + '. ' + String(line).slice(0,100), 14, y);
        y += 6;
        if (y > 270){ doc.addPage(); y = 20; }
      });
    } else {
      doc.text('No issues detected.', 14, y); y += 8;
    }
    y += 4;
    doc.text('Top transactions:', 14, y); y += 6;
    analysis.transactions.slice(0,30).forEach((t, idx) => {
      const line = (idx+1) + '. ' + t.date + ' | ' + t.vendor + ' | ' + t.amount.toFixed(2);
      doc.text(String(line).slice(0,120), 14, y);
      y += 6;
      if (y > 270){ doc.addPage(); y = 20; }
    });
    doc.save('expense-audit.pdf');
  }

  parseBtn.addEventListener('click', async () => {
    const file = fileInput.files[0];
    if (!file){ alert('Please choose a CSV file'); return; }
    const text = await file.text();
    const rows = parseCSV(text);
    if (!rows || rows.length === 0){ alert('No rows parsed from CSV'); return; }
    const tx = parseRows(rows);
    if (!tx || tx.length === 0){ alert('No valid transactions found. Make sure CSV has date, vendor, amount columns.'); return; }
    const analysis = analyze(tx);
    lastAnalysis = analysis;
    renderAnalysis(analysis);
    enableExports(analysis);
  });

})();
