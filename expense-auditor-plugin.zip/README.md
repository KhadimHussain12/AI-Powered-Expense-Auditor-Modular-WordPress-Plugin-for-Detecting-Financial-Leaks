# Expense Auditor - Basic Safe Version (WordPress Plugin)

## Overview
This plugin provides a **Basic Safe** client-side expense auditing tool. It is rule-based and runs entirely in the user's browser — no external API calls, no data sent outside the user's machine.

**Pitch:** "The leaks stop. The savings start."

## Features
- Shortcode: `[expense_auditor]`
- Upload CSV of transactions (required columns: `date`, `vendor`, `amount`; `category` optional)
- Client-side rule-based analysis:
  - Duplicate detection (exact duplicates)
  - Unusual amounts (z-score)
  - Month-over-month spikes
  - Suspicious / heavy vendors
- Client-side CSV export and PDF export (uses jsPDF CDN)
- Lightweight, vanilla PHP/JS/CSS — easy to extend

## Installation
1. Upload the `expense-auditor-plugin` folder to `/wp-content/plugins/`.
2. Activate the plugin via WordPress admin.
3. Use shortcode `[expense_auditor]` in a post or page.

## Notes
- PDF export depends on the jsPDF CDN. If you need offline usage, I can embed jsPDF locally into the plugin (larger size).
- For production or large datasets, consider implementing server-side parsing, pagination, and background processing (WP Cron).
- To add AI-powered analysis later, we can add a secure admin settings page to save API keys and perform server-side calls.

## Developer hints
- Main files:
  - `expense-auditor-plugin/expense-auditor.php` — plugin bootstrap.
  - `assets/js/app.js` — frontend logic.
  - `assets/css/style.css` — styling.
- The parser is intentionally simple; for robust CSV handling, consider using a server-side CSV library or a more advanced client CSV parser.

## License
MIT
